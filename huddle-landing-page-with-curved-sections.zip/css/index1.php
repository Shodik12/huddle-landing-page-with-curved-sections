<?php include("../config.php"); ?>

<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}
	?>



<!DOCTYPE html>
<html>
<head>
 <!-- Required meta tags -->
 <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="HandheldFriendly" content="true">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<body class="app sidebar-hidden"> 

<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">

<!-- Font Awesome 5-->
<link rel="stylesheet" href="../css/fontawesome.css">
<!-- Font Awesome-->
<link rel="stylesheet" href="../css/fontawesome.min.css">
<script src="../js/fontawesome.js"></script>
  <script src="../js/fontawesome.min.js"></script>

  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="../css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="../css/modal.css">


	<title>Web Kelas</title>
</head>
<nav class="navbar navbar-expand-lg navbar-secondary navbar-light bg-secondary"> <h5>Web Kelas</h5><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button> <div class="collapse navbar-collapse" id="navbarTogglerDemo01"> <ul class="navbar-nav mr-auto mt-2 mt-lg-0"> <li class="nav-item active"> <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a> </li> <li class="nav-item">
 <a class="nav-link" href="62895364386346">Kontak Admin(Dev)</a> </li> 
<a class="btn btn-danger" href="../logout.php">Logout</a>
<hr>

<hr>

</ul>  </div> </nav>
<body>

	<br>
	<div class="card">
<script>

var Digital=new Date()

var hours=Digital.getHours()


//Silahkan sesuaikan dengan pesan yang Anda inginkan

if (hours>=5&&hours<=11) //pesan pagi hari (05.00-11.00)

document.write('<b>Selamat Pagi <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours==12) //pesan siang hari (12.00-13.00)

document.write('<b>Selamat Siang <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours>=13&&hours<=17) //pesan sore hari(14.00-17.00)

document.write('<b>Selamat Sore <?php echo $_SESSION['nama']; ?>!.</b>')

else if (hours>=18&&hours<=20) //pesan petang hari (18.oo-20.00)

document.write('<b>Selamat Petang <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours>=21&&hours<=11) //pesan malam hari (21.00-23.00)

document.write('<b>Selamat Malam<?php echo $_SESSION['nama']; ?> !</b>')

else //pesan malam mejelang pagi(00.00-04.00)

document.write('<b>Selamat Malam <?php echo $_SESSION['nama']; ?>!</b>')

//edit by http://www.masbugie.com

</script>





      <div class="alert alert-primary" role="alert">
      <div class="card-header">
    		<h3>Daftar Siswa</h3>
  </div>
</div>

<?php


// buat query untuk ambil data dari database
$sql = "SELECT * FROM gambar WHERE id=$id";
$query = mysqli_query($connect, $sql);
$artikel = mysqli_fetch_assoc($query);

// jika data yang di-edit tidak ditemukan
if( mysqli_num_rows($query) < 1 ){
	die("data tidak ditemukan...");
}

?>


<?php echo "foto/$siswa['nama']" ?>




  <script src="https://unpkg.com/@popperjs/core@2"></script> <script src="../js/coreui.min.js"></script>

  <script src="../js/modal.js"></script>


  <script src="../js/coreui.bundle.js"></script>
</body></body>
</html>
